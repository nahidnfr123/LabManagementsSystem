import { MONTHS, SHORT_MONTHS, DAYS_OF_WEEK, SHORT_DAYS, WEEK_DAYS_HTML, EX_KEYS, DATA_KEY, DEFAULT_CLASS, SELECTED_FORMAT, DEFAULTS } from './vars'
import { hf } from './helpers'

/**
 * Date picker class
 */
class _duDatePicker {
	/**
	 * Creates date picker
	 * @param {HTMLInputElement} el Input element
	 * @param {Object} options Date picker options
	 */
	constructor(el, options) {
		var _ = this

		this.config = hf.extend(DEFAULTS, options)
		/**
		 * Determines if date picker is animating
		 */
		this.animating = false
		/**
		 * Determines if date picker is displayed/shown
		 */
		this.visible = false
		/**
		 * Input element
		 * @type {HTMLInputElement}
		 */
		this.input = el
		this.input.readonly = true
		this.fromEl = document.querySelector(this.config.fromTarget)
		this.toEl = document.querySelector(this.config.toTarget)
		this.input.hidden = this.config.range && (this.fromEl || this.toEl)
		this.viewMode = 'calendar'

		/**
		 * Date picker elements holder
		 * @type {Object}
		 */
		this.datepicker = {
			container: hf.createElem('div', { class: 'dcalendarpicker' }),
			wrapper: hf.createElem('div', { class: 'dudp__wrapper', tabindex: 0 }),
			header: {
				wrapper: hf.createElem('section', { class: 'dudp__calendar-header' }),
				selectedYear: hf.createElem('span', { class: 'dudp__sel-year' }),
				selectedDate: hf.createElem('span', { class: 'dcp_sel-date' }),
			},
			calendarHolder: {
				wrapper: hf.createElem('section', { class: 'dudp__cal-container' }),
				btnPrev: hf.createElem('span', { class: 'dudp__btn-cal-prev', role: 'button' }, '&lsaquo;', true),
				btnNext: hf.createElem('span', { class: 'dudp__btn-cal-next', role: 'button' }, '&rsaquo;', true),
				calendarViews: {
					wrapper: hf.createElem('div', { class: 'dudp__calendar-views' }),
					calendars: []
				},
				yearsView: hf.createElem('div', { class: 'dudp__years-view dp__hidden' }),
				monthsView: hf.createElem('div', { class: 'dudp__months-view dp__hidden' }),
				buttons: {
					wrapper: hf.createElem('div', { class: 'dudp__buttons' }),
					btnClear: hf.createElem('span', { class: 'dudp__button clear', role: 'button' }, 'Clear'),
					btnCancel: hf.createElem('span', { class: 'dudp__button cancel', role: 'button' }, 'Cancel'),
					btnOk: hf.createElem('span', { class: 'dudp__button ok', role: 'button' }, 'Ok'),
				}
			}
		}

		// set default value
		if (_.config.value) {
			_.input.value = _.config.value
			_.input.setAttribute('value', _.config.value)
		}

		this.minDate = _.input.dataset.mindate || _.config.minDate
		this.maxDate = _.input.dataset.maxdate || _.config.maxDate

		// current selected date, default is today if no value given
		var _date = new Date()

		if (_.config.range) {
			var value = _.input.value, _range = value.split(_.config.rangeDelim)

			if (value !== '' && _range.length < 2)
				throw new Error('duDatePicker: Invalid date range value')

			var _from = value === '' ? null : hf.parseDate.call(_, _range[0]).date,
				_to = value === '' ? null : hf.parseDate.call(_, _range[1]).date

			this.dateFrom = _from
			this.dateTo = _to
			this.rangeFrom = null
			this.rangeTo = null

			this.viewMonth = (_from ? _from : _date).getMonth()
			this.viewYear = (_from ? _from : _date).getFullYear()

			// set default value
			if (value) {
				var valueDisp = _.config.events && _.config.events.onRangeFormat ? _.formatRange(_from, _to) : value,
					formattedFrom = hf.formatDate(_from, _.config.format),
					outFrom = hf.formatDate(_from, _.config.outFormat || _.config.format),
					formattedTo = hf.formatDate(_to, _.config.format),
					outTo = hf.formatDate(_to, _.config.outFormat || _.config.format)

				_.input.value = valueDisp
				hf.setAttributes(_.input, {
					'value': valueDisp,
					'data-range-from': outFrom,
					'data-range-to': outTo
				})

				if (_.fromEl) {
					_.fromEl.value = formattedFrom
					hf.setAttributes(_.fromEl, {
						'value': formattedFrom,
						'data-value': outFrom
					})
				}

				if (_.toEl) {
					_.toEl.value = formattedTo
					hf.setAttributes(_.toEl, {
						'value': formattedFrom,
						'data-value': outTo
					})
				}
			}
		} else {
			this.date = _.input.value === '' ? _date : hf.parseDate.call(_, _.input.value).date
			this.selected = {
				year: _.date.getFullYear(),
				month: _.date.getMonth(),
				date: _.date.getDate()
			}

			this.viewMonth = _.selected.month
			this.viewYear = _.selected.year
		}

		/* input event handlers */
		function _inputClick() {
			_.showInFromEl = _.config.inline && _.fromEl && this === _.fromEl
			_.showInToEl = _.config.inline && _.toEl && this === _.toEl
			_.show()
		}

		function _inputKeydown(e) {
			if (e.keyCode === 13) {
				_.showInFromEl = _.config.inline && _.fromEl && this === _.fromEl
				_.showInToEl = _.config.inline && _.toEl && this === _.toEl
				_.show()
			}
			return !(EX_KEYS.indexOf(e.which) < 0)
		}

		/**
		 * Unbinds input `click` and `keydown` event handlers
		 */
		this._unbindInput = function () {
			_.input.readonly = false
			_.input.removeEventListener('click', _inputClick)
			_.input.removeEventListener('keydown', _inputKeydown)

			if (_.fromEl) {
				_.fromEl.readonly = false
				_.fromEl.removeEventListener('click', _inputClick)
				_.fromEl.removeEventListener('keydown', _inputKeydown)
			}

			if (_.toEl) {
				_.toEl.readonly = false
				_.toEl.removeEventListener('click', _inputClick)
				_.toEl.removeEventListener('keydown', _inputKeydown)
			}
		}

		hf.addEvent(_.input, 'click', _inputClick)
		hf.addEvent(_.input, 'keydown', _inputKeydown)

		if (_.fromEl) {
			_.fromEl.readonly = true
			hf.addEvent(_.fromEl, 'click', _inputClick)
			hf.addEvent(_.fromEl, 'keydown', _inputKeydown)
		}

		if (_.toEl) {
			_.toEl.readonly = true
			hf.addEvent(_.toEl, 'click', _inputClick)
			hf.addEvent(_.toEl, 'keydown', _inputKeydown)
		}

		// initialize
		this._init()
		this._setSelection()
	}
	/**
	 * Initializes the date picker
	 */
	_init() {
		var _ = this,
			picker = _.datepicker,
			header = picker.header,
			calendarHolder = picker.calendarHolder,
			buttons = calendarHolder.buttons,
			_selected = _.selected ? _.selected : new Date()

		// Setup header
		if (!_.config.inline) {
			hf.appendTo([header.selectedYear, header.selectedDate], header.wrapper)
			hf.appendTo(header.wrapper, picker.wrapper)

			hf.addEvent(header.selectedYear, 'click', function () {
				if (_.viewMode !== 'years')
					_._switchView('years')
			})

			hf.addEvent(header.selectedDate, 'click', function () {
				var now = new Date(),
					_month = _.config.range ? now.getMonth() : _.selected.month,
					_year = _.config.range ? now.getFullYear() : _.selected.year

				if ((_.viewMonth !== _month || _.viewYear !== _year) || _.viewMode !== 'calendar') {
					_.viewMonth = _month
					_.viewYear = _year
					_._setupCalendar()
					_._switchView('calendar')
				}
			})
		}

		// Setup months view
		var _month = 0
		for (var r = 1; r < 4; r++) {
			var monthRow = hf.createElem('div', { class: 'dudp__month-row' })

			for (var i = 0; i < 4; i++) {
				var monthElem = hf.createElem('span', { class: 'dudp__month' })

				if (_month === _selected.month)
					monthElem.classList.add('selected')

				monthElem.innerText = SHORT_MONTHS[_month]
				monthElem.dataset.month = _month
				hf.appendTo(monthElem, monthRow)
				hf.addEvent(monthElem, 'click', function (e) {
					var _this = this, _data = _this.dataset.month

					_.viewMonth = _data

					_._setupCalendar()
					_._switchView('calendar')
				})

				_month++
			}
			hf.appendTo(monthRow, calendarHolder.monthsView)
		}

		// Setup years view
		hf.appendTo(_._getYears(), calendarHolder.yearsView)

		if (_.config.clearBtn)
			hf.appendTo(buttons.btnClear, buttons.wrapper)
		if (_.config.cancelBtn)
			hf.appendTo(buttons.btnCancel, buttons.wrapper)

		if (!_.config.auto || _.config.range)
			hf.appendTo(buttons.btnOk, buttons.wrapper)

		hf.appendTo([
			calendarHolder.btnPrev,
			calendarHolder.btnNext,
			calendarHolder.calendarViews.wrapper,
			calendarHolder.monthsView,
			calendarHolder.yearsView,
			buttons.wrapper
		], calendarHolder.wrapper)
		hf.appendTo(calendarHolder.wrapper, picker.wrapper)

		hf.appendTo(picker.wrapper, picker.container)
		hf.appendTo(picker.container, document.body)

		if (_.config.inline)
			picker.container.setAttribute('inline', true)

		// Setup theme
		picker.wrapper.dataset.theme = _.input.dataset.theme || _.config.theme

		hf.addEvent(picker.wrapper, 'keydown', function (e) {
			if (e.keyCode === 27)
				_.hide() // esc
			else if (e.keyCode === 37)
				_._move('prev') // arrow left
			else if (e.keyCode === 39)
				_._move('next') // arrow right
		})

		if (_.config.inline)
			hf.addEvent(picker.wrapper, 'blur', function () { _.hide() })

		hf.addEvent(calendarHolder.btnPrev, 'click', function () { _._move('prev') })
		hf.addEvent(calendarHolder.btnNext, 'click', function () { _._move('next') })

		hf.addEvent(calendarHolder.calendarViews.wrapper, 'click', function (e) {
			if (e.target.classList.contains('cal-year')) {
				_._switchView('years')
			} else if (e.target.classList.contains('cal-month')) {
				_._switchView('months')
			}
		})

		if (_.config.clearBtn)
			hf.addEvent(buttons.btnClear, 'click', function () {
				_.setValue('')
				_.hide()
			})

		if (_.config.overlayClose) {
			hf.addEvent(picker.container, 'click', function () { _.hide() })
			hf.addEvent(picker.wrapper, 'click', function (e) { e.stopPropagation() })
		}

		if (_.config.cancelBtn) {
			hf.addEvent(buttons.btnCancel, 'click', function () { _.hide() })
		}

		hf.addEvent(buttons.btnOk, 'click', function () {
			if (_.config.range) {
				if (!_.rangeFrom || !_.rangeTo)
					return

				var _from = new Date(_.rangeFrom.year, _.rangeFrom.month, _.rangeFrom.date),
					_to = new Date(_.rangeTo.year, _.rangeTo.month, _.rangeTo.date)

				if (_._dateDisabled(_from) || _._dateDisabled(_to))
					return

				_.dateFrom = _from
				_.dateTo = _to
				_.setValue([hf.formatDate(_from, _.config.format), hf.formatDate(_to, _.config.format)].join(_.config.rangeDelim))
			} else {
				var _date = new Date(_.selected.year, _.selected.month, _.selected.date)

				if (_._dateDisabled(_date))
					return

				_.date = _date
				_.setValue(_.date)
			}

			_.hide()
		})

		if (_.config.events && _.config.events.ready)
			_.config.events.ready.call(_, _)
	}
	/**
	 * Determines if date is in the selected date range
	 * @param {Date} date Date object
	 */
	_inRange(date) {
		if (!this.config.range)
			return false

		var _ = this,
			_from = _.rangeFrom ? new Date(_.rangeFrom.year, _.rangeFrom.month, _.rangeFrom.date) : null,
			_to = _.rangeTo ? new Date(_.rangeTo.year, _.rangeTo.month, _.rangeTo.date) : null

		return (_from && date > _from) && (_to && date < _to)
	}
	/**
	 * Determines if date is disabled
	 * @param {Date} date Date object
	 * @returns {Boolean} `true` if specified date should be disabled, `false` otherwise
	 */
	_dateDisabled(date) {
		var _ = this, min = null, max = null,
			now = new Date(), today = new Date(now.getFullYear(), now.getMonth(), now.getDate()),
			_dates = _.config.disabledDates,
			_days = _.config.disabledDays,
			_inDates = _dates.filter(function (x) {
				if (x.indexOf('-') >= 0)
					return (date >= hf.parseDate.call(_, x.split('-')[0]).date && date <= hf.parseDate.call(_, x.split('-')[1]).date)

				else
					return hf.parseDate.call(_, x).date.getTime() === date.getTime()
			}).length > 0,
			_inDays = _days.indexOf(DAYS_OF_WEEK[date.getDay()]) >= 0 ||
				_days.indexOf(SHORT_DAYS[date.getDay()]) >= 0 ||
				_days.indexOf(SHORT_DAYS.map(function (x) { return x.substr(0, 2) })[date.getDay()]) >= 0

		if (_.minDate)
			min = _.minDate === "today" ? today : new Date(_.minDate)
		if (_.maxDate)
			max = _.maxDate === "today" ? today : new Date(_.maxDate)

		return (min && date < min) || (max && date > max) || (_inDates || _inDays)
	}
	/**
	 * @param {number} year Year
	 * @param {number} month Month
	 * @returns {HTMLSpanElement[]} Returns the dates of the specified month and year
	 */
	_getDates(year, month) {
		var _ = this, day = 1, now = new Date(),
			today = new Date(now.getFullYear(), now.getMonth(), now.getDate()),
			selected = _.config.range ? null : new Date(_.selected.year, _.selected.month, _.selected.date),
			rangeFrom = _.rangeFrom ? new Date(_.rangeFrom.year, _.rangeFrom.month, _.rangeFrom.date) : null,
			rangeTo = _.rangeTo ? new Date(_.rangeTo.year, _.rangeTo.month, _.rangeTo.date) : null,
			date = new Date(year, month, day), totalDays = hf.getDaysCount(date), nmStartDay = 1,
			weeks = []

		for (var week = 1; week <= 6; week++) {
			var daysOfWeek = []

			for (var idx = 0; idx < 7; idx++) {
				daysOfWeek.push(hf.createElem('span', { class: 'dudp__date' }))
			}

			while (day <= totalDays) {
				date.setDate(day)
				var dayOfWeek = date.getDay()

				daysOfWeek[dayOfWeek].dataset.date = day
				daysOfWeek[dayOfWeek].dataset.month = month
				daysOfWeek[dayOfWeek].dataset.year = year

				if (date.getTime() === today.getTime())
					daysOfWeek[dayOfWeek].classList.add('current')

				if (_._dateDisabled(date))
					daysOfWeek[dayOfWeek].classList.add('disabled')
				if (_._inRange(date))
					daysOfWeek[dayOfWeek].classList.add('in-range')

				if (week === 1 && dayOfWeek === 0) {
					break
				} else if (dayOfWeek < 6) {
					if (!_.config.range && date.getTime() === selected.getTime())
						daysOfWeek[dayOfWeek].classList.add('selected')
					if (_.config.range && rangeFrom && date.getTime() === rangeFrom.getTime())
						daysOfWeek[dayOfWeek].classList.add('range-from')
					if (_.config.range && rangeTo && date.getTime() === rangeTo.getTime())
						daysOfWeek[dayOfWeek].classList.add('range-to')

					daysOfWeek[dayOfWeek].innerText = day++
				} else {
					if (!_.config.range && date.getTime() === selected.getTime())
						daysOfWeek[dayOfWeek].classList.add('selected')
					if (_.config.range && rangeFrom && date.getTime() === rangeFrom.getTime())
						daysOfWeek[dayOfWeek].classList.add('range-from')
					if (_.config.range && rangeTo && date.getTime() === rangeTo.getTime())
						daysOfWeek[dayOfWeek].classList.add('range-to')

					daysOfWeek[dayOfWeek].innerText = day++
					break
				}
			}

			/* For days of previous and next month */
			if (week === 1 || week > 4) {
				// First week
				if (week === 1) {
					var prevMonth = new Date(year, month - 1, 1), prevMonthDays = hf.getDaysCount(prevMonth)

					for (var a = 6; a >= 0; a--) {
						if (daysOfWeek[a].innerText !== '')
							continue

						daysOfWeek[a].dataset.date = prevMonthDays
						daysOfWeek[a].dataset.month = month - 1
						daysOfWeek[a].dataset.year = year

						prevMonth.setDate(prevMonthDays)
						daysOfWeek[a].innerText = (prevMonthDays--)
						daysOfWeek[a].classList.add('dudp__pm')

						if (_._dateDisabled(prevMonth))
							daysOfWeek[a].classList.add('disabled')
						if (_._inRange(prevMonth))
							daysOfWeek[a].classList.add('in-range')

						if (prevMonth.getTime() === today.getTime())
							daysOfWeek[a].classList.add('current')
						if (!_.config.range && prevMonth.getTime() === selected.getTime())
							daysOfWeek[a].classList.add('selected')
						if (_.config.range && rangeFrom && prevMonth.getTime() === rangeFrom.getTime())
							daysOfWeek[a].classList.add('range-from')
						if (_.config.range && rangeTo && prevMonth.getTime() === rangeTo.getTime())
							daysOfWeek[a].classList.add('range-to')
					}
				}

				// Last week
				else if (week > 4) {
					var nextMonth = new Date(year, month + 1, 1)
					for (var a = 0; a <= 6; a++) {
						if (daysOfWeek[a].innerText !== '')
							continue

						daysOfWeek[a].dataset.date = nmStartDay
						daysOfWeek[a].dataset.month = month + 1
						daysOfWeek[a].dataset.year = year

						nextMonth.setDate(nmStartDay)
						daysOfWeek[a].innerText = (nmStartDay++)
						daysOfWeek[a].classList.add('dudp__nm')

						if (_._dateDisabled(nextMonth))
							daysOfWeek[a].classList.add('disabled')
						if (_._inRange(nextMonth))
							daysOfWeek[a].classList.add('in-range')

						if (nextMonth.getTime() === today.getTime())
							daysOfWeek[a].classList.add('current')
						if (!_.config.range && nextMonth.getTime() === selected.getTime())
							daysOfWeek[a].classList.add('selected')
						if (_.config.range && rangeFrom && nextMonth.getTime() === rangeFrom.getTime())
							daysOfWeek[a].classList.add('range-from')
						if (_.config.range && rangeTo && nextMonth.getTime() === rangeTo.getTime())
							daysOfWeek[a].classList.add('range-to')
					}
				}
			}
			weeks.push(daysOfWeek)
		}

		var calDates = []
		weeks.forEach(function (dow) {
			var calWeek = hf.createElem('div', { class: 'dudp__cal-week' })

			for (var i = 0; i < dow.length; i++) {
				var dateElem = dow[i]

				// Attach click handler for dates
				hf.addEvent(dateElem, 'click', function () {
					var _this = this, _year = _this.dataset.year, _month = _this.dataset.month,
						_date = _this.dataset.date,
						_selected = new Date(_year, _month, _date),
						isFrom = false

					if (_._dateDisabled(_selected))
						return

					if (_.config.range) {
						var rangeFrom = _.rangeFrom ? new Date(_.rangeFrom.year, _.rangeFrom.month, _.rangeFrom.date) : null,
							rangeTo = _.rangeTo ? new Date(_.rangeTo.year, _.rangeTo.month, _.rangeTo.date) : null

						if (!_.rangeFrom || (_.rangeFrom && _selected < rangeFrom) ||
							(_.rangeFrom && _.rangeTo && hf.dateDiff(rangeFrom, _selected) <= hf.dateDiff(_selected, rangeTo) && hf.dateDiff(rangeFrom, _selected) !== 0) ||
							(_.rangeFrom && _.rangeTo && rangeTo.getTime() === _selected.getTime())) {
							_.rangeFrom = { year: _year, month: _month, date: _date }
							isFrom = true
						} else if (!_.rangeTo || (_.rangeTo && _selected > rangeTo) ||
							(_.rangeFrom && _.rangeTo && hf.dateDiff(_selected, rangeTo) < hf.dateDiff(rangeFrom, _selected) && hf.dateDiff(_selected, rangeTo) !== 0) ||
							(_.rangeFrom && _.rangeTo && rangeFrom.getTime() === _selected.getTime())) {
							_.rangeTo = { year: _year, month: _month, date: _date }
							isFrom = false
						}

						_.datepicker.calendarHolder.calendarViews.wrapper.querySelectorAll('.dudp__date').forEach(function (delem) {
							var _deYear = delem.dataset.year, _deMonth = delem.dataset.month, _deDate = delem.dataset.date,
								_inRange = _._inRange(new Date(_deYear, _deMonth, _deDate))

							delem.classList[(_year === _deYear && _month === _deMonth && _date === _deDate) ? 'add' : 'remove'](isFrom ? 'range-from' : 'range-to')
							delem.classList[_inRange ? 'add' : 'remove']('in-range')
						})
					} else {
						_.datepicker.calendarHolder.calendarViews.wrapper.querySelectorAll('.dudp__date').forEach(function (delem) {
							var _deYear = delem.dataset.year,
								_deMonth = delem.dataset.month,
								_deDate = delem.dataset.date

							delem.classList[(_year === _deYear && _month === _deMonth && _date === _deDate) ? 'add' : 'remove']('selected')
						})


						_this.classList.add('selected')
						_.selected = { year: _year, month: _month, date: _date }
						_._setSelection()

						if (_.config.auto) {
							_.date = _selected
							_.setValue(_.date)
							_.hide()
						}
					}

					_.datepicker.calendarHolder.wrapper.querySelectorAll('.dudp__month').forEach(function (melem) {
						var _meMonth = melem.dataset.month

						melem.classList[_meMonth === _month ? 'add' : 'remove']('selected')
					})
				})

				hf.appendTo(dateElem, calWeek)
			}

			calDates.push(calWeek)
		})

		return calDates
	}
	/**
	 * @returns {HTMLSpanElement[]} Returns years range for the years view
	 */
	_getYears() {
		var _ = this, _minYear = _.viewYear - 50, _maxYear = _.viewYear + 25,
			_years = []

		for (var y = _minYear; y <= _maxYear; y++) {
			var yearElem = hf.createElem('span', { class: 'dudp__year' })

			if (y === _.viewYear)
				yearElem.classList.add('selected')

			yearElem.innerText = y
			yearElem.dataset.year = y
			hf.addEvent(yearElem, 'click', function () {
				var _this = this, _data = parseInt(_this.dataset.year)

				_.viewYear = _data
				if (!_.config.range)
					_.selected.year = _data
				_._setSelection()
				_._setupCalendar()
				_._switchView('calendar')
			})

			_years.push(yearElem)
		}

		return _years
	}
	/**
	 * Sets up the calendar views
	 */
	_setupCalendar() {
		var _ = this, viewsHolder = _.datepicker.calendarHolder.calendarViews, _year = +_.viewYear, _month = +_.viewMonth

		viewsHolder.calendars.length = 0

		var inView = {
			wrapper: hf.createElem('div', { class: 'dudp__calendar' }),
			header: hf.createElem('div', { class: 'dudp__cal-month-year' }),
			weekDays: hf.createElem('div', { class: 'dudp__weekdays' }, WEEK_DAYS_HTML, true),
			datesHolder: hf.createElem('div', { class: 'dudp__dates-holder' })
		}, prev = {
			wrapper: hf.createElem('div', { class: 'dudp__calendar' }),
			header: hf.createElem('div', { class: 'dudp__cal-month-year' }),
			weekDays: hf.createElem('div', { class: 'dudp__weekdays' }, WEEK_DAYS_HTML, true),
			datesHolder: hf.createElem('div', { class: 'dudp__dates-holder' })
		}, next = {
			wrapper: hf.createElem('div', { class: 'dudp__calendar' }),
			header: hf.createElem('div', { class: 'dudp__cal-month-year' }),
			weekDays: hf.createElem('div', { class: 'dudp__weekdays' }, WEEK_DAYS_HTML, true),
			datesHolder: hf.createElem('div', { class: 'dudp__dates-holder' })
		}, prevMonth = _month === 0 ? 11 : _month - 1,
			nextMonth = _month === 11 ? 0 : _month + 1,
			prevYear = _month === 0 ? _year - 1 : _year,
			nextYear = _month === 11 ? _year + 1 : _year

		hf.appendTo([
			hf.createElem('span', { class: 'cal-month' }, MONTHS[prevMonth]),
			hf.createElem('span', { class: 'cal-year' }, prevYear)
		], prev.header)
		hf.appendTo(_._getDates(prevYear, prevMonth), prev.datesHolder)
		hf.appendTo([prev.header, prev.weekDays, prev.datesHolder], prev.wrapper)
		viewsHolder.calendars.push(prev)

		hf.appendTo([
			hf.createElem('span', { class: 'cal-month' }, MONTHS[_month]),
			hf.createElem('span', { class: 'cal-year' }, _year)
		], inView.header)
		hf.appendTo(_._getDates(_year, _month), inView.datesHolder)
		hf.appendTo([inView.header, inView.weekDays, inView.datesHolder], inView.wrapper)
		viewsHolder.calendars.push(inView)

		hf.appendTo([
			hf.createElem('span', { class: 'cal-month' }, MONTHS[nextMonth]),
			hf.createElem('span', { class: 'cal-year' }, nextYear)
		], next.header)
		hf.appendTo(_._getDates(nextYear, nextMonth), next.datesHolder)
		hf.appendTo([next.header, next.weekDays, next.datesHolder], next.wrapper)
		viewsHolder.calendars.push(next)

		hf.empty(viewsHolder.wrapper)

		hf.appendTo([
			prev.wrapper,
			inView.wrapper,
			next.wrapper
		], viewsHolder.wrapper)
	}
	/**
	 * Switches view of date picker (calendar, months, years)
	 * @param {string} view View name
	 */
	_switchView(view) {
		if (view !== 'calendar' && view !== 'months' && view !== 'years')
			return

		var _ = this, picker = _.datepicker,
			monthsView = picker.calendarHolder.monthsView,
			yearsView = picker.calendarHolder.yearsView,
			calViews = picker.calendarHolder.calendarViews.wrapper,
			_animDuration = 250,
			_oldView = _.viewMode

		_.viewMode = view

		switch (_.viewMode) {
			case 'calendar':
				var _calendar = calViews.querySelector('.dudp__calendar:nth-child(2)') // current month in view

				calViews.classList.add('dp__animate-out')
				calViews.classList.remove('dp__hidden')
				if (_oldView !== 'calendar')
					_calendar.classList.add('dp__zooming', 'dp__animate-zoom')
				picker.calendarHolder.btnPrev.classList.remove('dp__hidden')
				picker.calendarHolder.btnNext.classList.remove('dp__hidden')

				setTimeout(() => {
					calViews.classList.remove('dp__animate-out')
					if (_oldView !== 'calendar')
						_calendar.classList.remove('dp__animate-zoom')
				}, 10)
				monthsView.classList.add('dp__animate-out')
				yearsView.classList.add('dp__hidden')

				setTimeout(() => {
					if (_oldView !== 'calendar')
						_calendar.classList.remove('dp__zooming')
					monthsView.classList.add('dp__hidden')
					monthsView.classList.remove('dp__animate-out')
				}, _animDuration)
				break
			case 'months':
				picker.calendarHolder.btnPrev.classList.add('dp__hidden')
				picker.calendarHolder.btnNext.classList.add('dp__hidden')
				calViews.classList.add('dp__animate-out')
				monthsView.classList.add('dp__animate-out')
				monthsView.classList.remove('dp__hidden')

				setTimeout(() => {
					monthsView.classList.remove('dp__animate-out')
				}, 10)
				setTimeout(() => {
					calViews.classList.add('dp__hidden')
					calViews.classList.remove('dp__animate-out')
				}, _animDuration)
				break
			case 'years':
				hf.empty(yearsView)
				hf.appendTo(_._getYears(), yearsView)

				var _selYear = yearsView.querySelector('.dudp__year.selected')

				yearsView.scrollTop = _selYear.offsetTop - 120

				picker.calendarHolder.btnPrev.classList.add('dp__hidden')
				picker.calendarHolder.btnNext.classList.add('dp__hidden')

				monthsView.classList.add('dp__animate-out')
				calViews.classList.add('dp__animate-out')
				yearsView.classList.remove('dp__hidden')

				setTimeout(() => {
					calViews.classList.add('dp__hidden')
					calViews.classList.remove('dp__animate-out')
					monthsView.classList.add('dp__hidden')
					monthsView.classList.remove('dp__animate-out')
				}, _animDuration)
				break
		}
	}
	/**
	 * Moves the calendar to specified direction (previous or next)
	 * @param {string} direction Movement direction
	 */
	_move(direction) {
		if (direction !== 'next' && direction !== 'prev')
			return

		var _ = this

		if (_.animating)
			return

		var picker = _.datepicker, viewsHolder = picker.calendarHolder.calendarViews, _animDuration = 250, _isNext = direction === 'next'

		if (_isNext ? _.viewMonth + 1 > 11 : _.viewMonth - 1 < 0)
			_.viewYear += (_isNext ? 1 : -1)
		_.viewMonth = _isNext ? (_.viewMonth + 1 > 11 ? 0 : _.viewMonth + 1) : (_.viewMonth - 1 < 0 ? 11 : _.viewMonth - 1)

		_.animating = true

		//Start animation
		var animateClass = 'dp__animate-' + (_isNext ? 'left' : 'right')

		viewsHolder.wrapper.querySelectorAll('.dudp__calendar').forEach(function (cal) {
			cal.classList.add(animateClass)
		})

		//Setup new (previos or next) month calendar
		var _year = _.viewYear, _month = _isNext ? _.viewMonth + 1 : _.viewMonth - 1

		if (_isNext ? _month > 11 : _month < 0) {
			_month = _isNext ? 0 : 11
			_year += _isNext ? 1 : -1
		}
		var newCalDates = _._getDates(_year, _month),
			newCalEl = {
				wrapper: hf.createElem('div', { class: 'dudp__calendar' }),
				header: hf.createElem('div', { class: 'dudp__cal-month-year' }),
				weekDays: hf.createElem('div', { class: 'dudp__weekdays' }, WEEK_DAYS_HTML, true),
				datesHolder: hf.createElem('div', { class: 'dudp__dates-holder' })
			}

		// newCalEl.header.innerText = fns.formatDate(new Date(_year, _month, 1), MONTH_HEAD_FORMAT)
		hf.appendTo([
			hf.createElem('span', { class: 'cal-month' }, MONTHS[_month]),
			hf.createElem('span', { class: 'cal-year' }, _year)
		], newCalEl.header)
		hf.appendTo(newCalDates, newCalEl.datesHolder)
		hf.appendTo([newCalEl.header, newCalEl.weekDays, newCalEl.datesHolder], newCalEl.wrapper)

		setTimeout(() => {
			hf.appendTo(newCalEl.wrapper, viewsHolder.wrapper, _isNext ? undefined : 0)
			viewsHolder.wrapper.querySelectorAll('.dudp__calendar').forEach(function (cal) {
				cal.classList.remove(animateClass)
			})
			viewsHolder.wrapper.removeChild(viewsHolder.calendars[_isNext ? 0 : 2].wrapper)
			viewsHolder.calendars[_isNext ? 'shift' : 'pop']()
			viewsHolder.calendars[_isNext ? 'push' : 'unshift'](newCalEl)

			_.animating = false
		}, _animDuration)
	}
	/**
	 * Resets the selection to the date value of the input
	 */
	_resetSelection() {
		var _ = this

		if (_.config.range) {
			var _date = _.dateFrom ? _.dateFrom : new Date()

			_.rangeFrom = _.dateFrom ? { year: _.dateFrom.getFullYear(), month: _.dateFrom.getMonth(), date: _.dateFrom.getDate() } : null
			_.rangeTo = _.dateTo ? { year: _.dateTo.getFullYear(), month: _.dateTo.getMonth(), date: _.dateTo.getDate() } : null

			_.viewYear = _date.getFullYear()
			_.viewMonth = _date.getMonth()
		} else {
			_.selected = { year: _.date.getFullYear(), month: _.date.getMonth(), date: _.date.getDate() }
			_.viewYear = _.selected.year
			_.viewMonth = _.selected.month
		}

		_.datepicker.calendarHolder.monthsView.querySelectorAll('.dudp__month').forEach(function (melem) {
			var _meMonth = parseInt(melem.dataset.month),
				_month = _.config.range ? _.dateFrom ? _.dateFrom.getMonth() : null : _.selected.month

			melem.classList[_meMonth === _month ? 'add' : 'remove']('selected')
		})
	}
	/**
	 * Sets the section display (datepicker header)
	 */
	_setSelection() {
		var _ = this, picker = _.datepicker,
			selected = _.config.range ? new Date() : new Date(_.selected.year, _.selected.month, _.selected.date)

		picker.header.selectedYear.innerText = selected.getFullYear()
		picker.header.selectedDate.innerText = hf.formatDate(selected, SELECTED_FORMAT)
	}
	/**
	 * Sets the value of the input
	 * @param {(string|Date)} value The new input value. If the value specified is a string, it will be parsed using `config.format`.
	 */
	setValue(value) {
		if (typeof value === 'undefined')
			throw new Error('Expecting a value.')
		var _ = this, _empty = typeof value === 'string' && value === '', changeData = null

		if (_.config.range) {
			var _range = _empty ? [] : value.split(_.config.rangeDelim)

			if (value !== '' && _range.length < 2)
				throw new Error('Invalid date range value.')

			var now = new Date(),
				_from = _empty ? null : hf.parseDate.call(_, _range[0]).date,
				_to = _empty ? null : hf.parseDate.call(_, _range[1]).date,
				formattedFrom = _empty ? '' : hf.formatDate(_from, _.config.format),
				outFrom = _empty ? '' : hf.formatDate(_from, _.config.outFormat || _.config.format),
				formattedTo = _empty ? '' : hf.formatDate(_to, _.config.format),
				outTo = _empty ? '' : hf.formatDate(_to, _.config.outFormat || _.config.format),
				valueDisp = _empty ? '' : (
					_.config.events && _.config.events.onRangeFormat ? _.formatRange(_from, _to) : _range[0] === _range[1] ? _range[0] : value)

			_.dateFrom = _from
			_.dateTo = _to
			_.viewYear = (_from ? _from : now).getFullYear()
			_.viewMonth = (_from ? _from : now).getMonth()
			_.input.value = valueDisp
			hf.setAttributes(_.input, {
				'value': valueDisp,
				'data-range-from': outFrom,
				'data-range-to': outTo
			})

			if (_.fromEl) {
				_.fromEl.value = formattedFrom
				hf.setAttributes(_.fromEl, {
					'value': formattedFrom,
					'data-value': outFrom
				})
			}

			if (_.toEl) {
				_.toEl.value = formattedTo
				hf.setAttributes(_.toEl, {
					'value': formattedTo,
					'data-value': outTo
				})
			}

			changeData = {
				_dateFrom: _from, dateFrom: _empty ? null : formattedFrom,
				_dateTo: _to, dateTo: _empty ? null : formattedTo,
				value: valueDisp
			}
		} else {
			var date = typeof value === 'string' ? (
				_empty ? new Date() : hf.parseDate.call(_, value, _.config.format).date) : value,
				formatted = _empty ? '' : hf.formatDate(date, _.config.format)

			_.date = date
			_.viewYear = date.getFullYear()
			_.viewMonth = date.getMonth()
			_.input.value = formatted
			_.input.setAttribute('value', formatted)

			changeData = {
				_date: _empty ? null : _.date,
				date: _empty ? null : hf.formatDate(_.date, _.config.outFormat || _.config.format)
			}
		}

		hf.triggerChange(_.input, changeData)

		if (_.config.events && _.config.events.dateChanged)
			_.config.events.dateChanged.call(_, changeData, _)
	}
	/**
	 * Returns formatted string representation of specified date
	 * @param {Date} date Date object
	 * @param {string} format Date format
	 */
	formatDate(date, format) { return hf.formatDate(date, format) }
	/**
	 * Formats specified date range to string (for display)
	 * @param {Date} from Date from
	 * @param {Date} to Date to
	 * @returns {string} Formatted date range
	 */
	formatRange(from, to) { return this.config.events.onRangeFormat.call(this, from, to, this) }
	/**
	 * Shows the date picker
	 */
	show() {
		var _ = this
		setTimeout(() => {
			hf.setAttributes(document.body, { 'datepicker-display': 'on' })
			_._resetSelection()
			_._setSelection()
			_._setupCalendar()
			_.datepicker.container.classList.add('dp__open')

			if (_.config.inline) {
				var inputRef = _.showInFromEl ? _.fromEl : _.showInToEl ? _.toEl : _.input,
					offset = hf.calcOffset(inputRef),
					picker_dim = {
						height: _.datepicker.wrapper.offsetHeight,
						width: _.datepicker.wrapper.offsetWidth
					},
					screen_dim = hf.screenDim(),
					below = offset.top + picker_dim.height < screen_dim.height,
					left_side = offset.left + picker_dim.width < screen_dim.width,
					offsetCss = {},
					scroll = {
						y: window.scrollY,
						x: window.scrollX
					}

				offsetCss[below ? 'top' : 'bottom'] = `${below ? offset.top - scroll.y : offset.bottom}px`
				offsetCss[left_side ? 'left' : 'right'] = `${left_side ? offset.left - scroll.x : offset.right}px`

				_.datepicker.container.removeAttribute('style')
				hf.setStyles(_.datepicker.container, offsetCss)
			}

			_.datepicker.wrapper.focus()
			_.visible = true
			_.input.blur()

			if (_.config.events && _.config.events.shown)
				_.config.events.shown.call(_, _)
		}, 0)
	}
	/**
	 * Hides the date picker
	 */
	hide() {
		var _ = this

		_.datepicker.container.classList.add('dp__closing')
		_.visible = false
		_.input.focus()
		document.body.removeAttribute('datepicker-display')
		setTimeout(() => {
			_._switchView('calendar') // Reset view to calendar
			_.datepicker.container.classList.remove('dp__closing', 'dp__open')

			if (_.config.events && _.config.events.hidden)
				_.config.events.hidden.call(_, _)
		}, 200)
	}
	/**
	 * Destroys the date picker plugin
	 */
	destroy() {
		this._unbindInput()
		document.body.removeChild(this.datepicker.container)
		delete this.input[DATA_KEY]
	}
}

/**
 * Creates date picker
 */
function duDatepicker() {
	var args = arguments,
		arg0 = args[0], arg0IsList = arg0 instanceof NodeList || Array.isArray(arg0), arg0IsElem = arg0 instanceof Element,
		inputs = typeof arg0 === 'string' ? document.querySelectorAll(arg0) :
			(arg0IsList ? arg0 : (arg0IsElem ? [arg0] : document.querySelectorAll(DEFAULT_CLASS))),
		options = typeof arg0 === 'object' && !(arg0IsList) && !(arg0IsElem) ? arg0 : args[1] && typeof args[1] === 'object' ? args[1] : {}

	Array.from(inputs).forEach(function (el) {
		var picker = el[DATA_KEY]

		if (!picker)
			el[DATA_KEY] = (picker = new _duDatePicker(el, options))

		if ((typeof arg0 === 'string' || arg0IsList || arg0IsElem) && (args[1] && typeof args[1] === 'string')) {
			picker[args[1]].apply(picker, Array.prototype.slice.call(args).slice(2))
		}
	})
}

export default duDatepicker

