# bs-timepicker-responsive-table-fixed
jQuery timepicker works well with bootstrap table responsive and with all other elements.
```
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Timepicker Demo</title>
	<script src="./lib/jquery.js"></script>
	<link rel="stylesheet" href="../dist/css/timepicker.css">
	<script src="../dist/js/timepicker.js"></script>
</head>
<body>
	<input type="text" class="bs-timepicker">
	<script>
		$('.bs-timepicker').timepicker();
	</script>
</body>
</ HTML>
```